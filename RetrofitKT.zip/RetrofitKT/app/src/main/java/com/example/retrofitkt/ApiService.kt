package com.example.retrofitkt

import com.example.retrofitkt.model.UserDataModel
import retrofit2.Call
import retrofit2.http.GET

interface ApiService {
    @GET(FINAL_URL_PATH) // Add the endpoint path here
    fun getData(): Call<List<UserDataModel>>
}