package com.example.retrofitkt

const val FINAL_URL = "https://jsonplaceholder.typicode.com/"
const val FINAL_URL_PATH = "posts"