package com.example.retrofitkt

import android.content.Context
import android.net.ConnectivityManager
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.retrofitkt.adapter.AllDataAdapter
import com.example.retrofitkt.databinding.ActivityMainBinding
import com.example.retrofitkt.model.UserDataModel
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var recyclerView: RecyclerView
    private lateinit var allDataAdapter: AllDataAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        init()
    }

    private fun init() {
        setData()
        buttonClick()
    }

    private fun setData() {
        recyclerView = binding.rvShowAllData
        recyclerView.setHasFixedSize(true)
        recyclerView.layoutManager = LinearLayoutManager(this@MainActivity)
    }

    private fun buttonClick() {
        binding.btnGetData.setOnClickListener {
            if (isNetworkAvailable()) {
                fetchData()
            } else {
                Toast.makeText(this, getString(R.string.internet_check), Toast.LENGTH_SHORT).show()
            }
        }
    }

    /** this code helps you to check the  */
    private fun isNetworkAvailable(): Boolean {
        val connectivityManager =
            getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkInfo = connectivityManager.activeNetworkInfo
        return networkInfo != null && networkInfo.isConnected
    }

    /** this data is fetching the data from the api that you call in that url */
    private fun fetchData() {
        val url = FINAL_URL

        val retrofit: Retrofit = Retrofit.Builder()
            .baseUrl(url)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        val api: ApiService = retrofit.create(ApiService::class.java)

        val call: Call<List<UserDataModel>> = api.getData()

        call.enqueue(object : Callback<List<UserDataModel>> {
            override fun onResponse(
                call: Call<List<UserDataModel>>,
                response: Response<List<UserDataModel>>
            ) {
                if (response.isSuccessful) {
                    val data: List<UserDataModel>? = response.body()
                    if (data != null) {
                        allDataAdapter = AllDataAdapter(data)
                        recyclerView.adapter = allDataAdapter
                    }
                }
            }
            override fun onFailure(call: Call<List<UserDataModel>>, t: Throwable) {
                Toast.makeText(
                    this@MainActivity,
                    getString(R.string.fetch_show_text)+"${t.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }
}
