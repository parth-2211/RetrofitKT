package com.example.retrofitkt.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.retrofitkt.databinding.ItemShowDataBinding
import com.example.retrofitkt.model.UserDataModel

class AllDataAdapter(private val userData: List<UserDataModel>) :
    RecyclerView.Adapter<AllDataAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: ItemShowDataBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            ItemShowDataBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = userData[position]
        holder.binding.tvMainUserId.text = item.userId.toString()
        holder.binding.tvMainID.text = item.id.toString()
        holder.binding.tvMainTitle.text = item.title
        holder.binding.tvMainBody.text = item.body
    }

    override fun getItemCount(): Int = userData.size

}