package com.example.retrofitkt.model

data class UserDataModel(
    val userId: Int,
    val id: Int,
    val title : String,
    val body : String
)
